import React, { useState, useRef } from 'react';

// Component using useState
const StateComponent = () => {
  const [count, setCount] = useState(0);

  const increment = () => {
    setCount(count + 1);
  };

  return (
    <div>
      <h1>State Component</h1>
      <p>Count: {count}</p>
      <button onClick={increment}>Increment</button>
    </div>
  );
};

// Component using useRef
const RefComponent = () => {
  const countRef = useRef(0);

  const increment = () => {
    countRef.current += 1;
    console.log('RefComponent count:', countRef.current);
  };

  return (
    <div>
      <h1>Ref Component</h1>
      <p>Count: {countRef.current}</p>
      <button onClick={increment}>Increment</button>
    </div>
  );
};

// Difference between useRef and useState

// Persistence of Values:

// useRef: Allows you to persist values between renders without causing a re-render.
// useState: Causes a re-render whenever the state value changes.
// Triggering Re-renders:

// useRef: Changes to values stored with useRef do not trigger a re-render.
// useState: Any change to the state value triggers a re-render of the component.
// Usage for Mutable Values:

// useRef: Useful for storing mutable values that don't necessitate a re-render.
// useState: Ideal for storing values that should prompt a re-render when changed.
// Typical Use Cases:

// useRef: Often used for tasks like managing focus, accessing imperative DOM methods, or storing mutable values without re-rendering.
// useState: Commonly used for managing component state, such as form input values, toggles, or any data that necessitates re-rendering.


const DifferenceBetweenHooks = () => (
  <div>
    <StateComponent />
    <RefComponent />
  </div>
);

export default DifferenceBetweenHooks;
