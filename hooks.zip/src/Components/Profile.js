import  { useContext, useEffect, useReducer } from 'react';
import { UserContext } from './UserContext';

const useProfileData = () => {
  const { username } = useContext(UserContext);

  const initialState = {
    loading: true,
    userData: null
  };

  const reducer = (state, action) => {
    switch (action.type) {
      case 'FETCH_SUCCESS':
        return {
          loading: false,
          userData: action.payload
        };
      case 'FETCH_ERROR':
        return {
          loading: false,
          userData: null
        };
      default:
        return state;
    }
  };

  const [state, dispatch] = useReducer(reducer, initialState);

  useEffect(() => {
    const fetchData = async () => {
      try {
           const mockData = {
           name: 'Manjima',
           country: 'India',
           gender: 'Female',
           pan: '1A654K4E',
};
await new Promise(resolve => setTimeout(resolve, 1000));
dispatch({ type: 'FETCH_SUCCESS', payload: mockData });
} catch (error) {
console.error('Error fetching profile data:', error);
dispatch({ type: 'FETCH_ERROR', payload: error.message });
}
};

fetchData();
}, []);

return state;
};

export default useProfileData;










