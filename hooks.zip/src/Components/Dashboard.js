import React from 'react';
import useProfileData from './Profile';
import { Link } from 'react-router-dom';

const Dashboard = () => {
  const { username, loading, userData } = useProfileData();

  return (
    <div>
      <h1>Dashboard</h1>
      <h2>Welcome {username}</h2>
      {loading ? (
        <p>Loading...</p>
      ) : (
        <div>
          {userData && (
            <>
              <p>Name: {userData.name}</p>
              <p>Country: {userData.country}</p>
              <p>Gender: {userData.gender}</p>
              <p>PAN: {userData.pan}</p>
            </>
          )}
          <Link to="/hooks">DifferenceBetweenHooks</Link>
        </div>
      )}
    </div>
  );
};

export default Dashboard;














// import React, { useContext } from 'react';
// import { UserContext } from './UserContext';
// import { Link} from 'react-router-dom';

// const Dashboard = () => {
//   const { username } = useContext(UserContext);

//   return(
//     <div>
//      <h1>Welcome, {username}!</h1>
//      <Link to= "/profile">Profile</Link>
//      </div>
//   );

// };

// export default Dashboard;
