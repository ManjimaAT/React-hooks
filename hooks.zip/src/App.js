import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Login from './Components/Login';
import Dashboard from './Components/Dashboard';
import DifferenceBetweenHooks from './Components/DifferenceBetweenHooks';
import './App.css';

function App() {
  return (
    
    <Router>
        <Routes>
          <Route path="/" exact element={<Login/>} />
          <Route path="/dashboard" element={<Dashboard/>} />
           <Route path='/hooks' element={<DifferenceBetweenHooks/>} />
        </Routes>
    </Router>
    
  );
}

export default App;
